const db = require("../config/database");
const bcrypt = require("bcrypt");
const { generateToken } = require("../utils/jwt");

const register = async (email, name, password) => {
  const [result] = await db.query("SELECT id_user FROM users WHERE email = ?", [
    email,
  ]);
  if (result.length > 0) {
    const err = new Error("Email already registered");
    err.status = 400;
    throw err;
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  await db.query("INSERT INTO users (email, name, password) VALUES (?, ?, ?)", [
    email,
    name,
    hashedPassword,
  ]);

  return { message: "Registration successful" };
};

const login = async (email, password) => {
  const [result] = await db.query("SELECT * FROM users WHERE email = ?", [
    email,
  ]);

  if (result.length === 0) {
    const err = new Error("Invalid email or password");
    err.status = 401;
    throw err;
  }

  const user = result[0];
  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    const err = new Error("Invalid email or password");
    err.status = 401;
    throw err;
  }

  const token = generateToken(user.id_user, user.name, user.email);
  return {
    token,
    user: {
      id: user.id_user,
      name: user.name,
      email: user.email,
    },
  };
};

module.exports = { register, login };
