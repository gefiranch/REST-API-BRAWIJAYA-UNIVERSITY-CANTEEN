const db = require("../config/database");

const getAllCanteens = async () => {
  const [result] = await db.query("SELECT * FROM canteens");
  return result;
};

const getCanteenById = async (id) => {
  const [result] = await db.query(
    "SELECT * FROM canteens WHERE id_canteen = ?",
    [id]
  );

  if (result.length === 0) {
    const err = new Error("Canteen not found");
    err.status = 404;
    throw err;
  }

  return result[0];
};

module.exports = { getAllCanteens, getCanteenById };
