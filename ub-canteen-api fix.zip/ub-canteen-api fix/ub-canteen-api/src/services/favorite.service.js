const db = require("../config/database");

const getFavoritesByUserId = async (userId) => {
  const [result] = await db.query(
    `SELECT c.* FROM favorites f
     JOIN canteens c ON f.id_canteen = c.id_canteen
     WHERE f.id_user = ?
     ORDER BY f.id_like DESC`,
    [userId]
  );
  return result;
};

const addFavorite = async (userId, canteenId) => {
  const [exist] = await db.query(
    "SELECT id_like FROM favorites WHERE id_user = ? AND id_canteen = ?",
    [userId, canteenId]
  );

  if (exist.length > 0) {
    const err = new Error("Canteen already in favorites");
    err.status = 409;
    throw err;
  }

  await db.query("INSERT INTO favorites (id_user, id_canteen) VALUES (?, ?)", [
    userId,
    canteenId,
  ]);

  return true;
};

const removeFavorite = async (userId, canteenId) => {
  const [result] = await db.query(
    "DELETE FROM favorites WHERE id_user = ? AND id_canteen = ?",
    [userId, canteenId]
  );

  if (result.affectedRows === 0) {
    const err = new Error("Canteen not found in favorites");
    err.status = 404;
    throw err;
  }

  return true;
};

module.exports = { getFavoritesByUserId, addFavorite, removeFavorite };
