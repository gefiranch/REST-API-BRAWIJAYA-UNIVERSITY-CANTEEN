const db = require("../config/database");

const getCommentsByUserId = async (userId) => {
  const [result] = await db.query(
    `SELECT c.comment, c.id_comment, ct.name AS canteen_name
     FROM comments c
     JOIN canteens ct ON c.id_canteen = ct.id_canteen
     WHERE c.id_user = ?`,
    [userId]
  );
  return result;
};

const getCommentsByCanteenId = async (canteenId) => {
  const [result] = await db.query(
    `SELECT comments.comment, users.name AS user_name
     FROM comments
     JOIN users ON comments.id_user = users.id_user
     WHERE comments.id_canteen = ?
     ORDER BY comments.id_comment DESC`,
    [canteenId]
  );
  return result;
};

const addComment = async (userId, canteenId, comment) => {
  await db.query(
    "INSERT INTO comments (id_user, id_canteen, comment) VALUES (?, ?, ?)",
    [userId, canteenId, comment]
  );
  return true;
};

const removeComment = async (commentId, userId) => {
  const [result] = await db.query(
    "DELETE FROM comments WHERE id_comment = ? AND id_user = ?",
    [commentId, userId]
  );

  if (result.affectedRows === 0) {
    const err = new Error("Comment not found");
    err.status = 404;
    throw err;
  }

  return true;
};

module.exports = {
  getCommentsByUserId,
  getCommentsByCanteenId,
  addComment,
  removeComment,
};
