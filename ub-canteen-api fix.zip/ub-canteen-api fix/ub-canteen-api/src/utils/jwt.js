const jwt = require("jsonwebtoken");

const SECRET = "final_project_gefi";

const generateToken = (id, name, email) => {
  try {
    return jwt.sign({ id, name, email }, SECRET, { expiresIn: "1d" });
  } catch (err) {
    throw new Error("Error generating token");
  }
};

const verifyToken = (token) => {
  try {
    return jwt.verify(token, SECRET);
  } catch (err) {
    throw new Error("Error verifying token");
  }
};

module.exports = { generateToken, verifyToken };
