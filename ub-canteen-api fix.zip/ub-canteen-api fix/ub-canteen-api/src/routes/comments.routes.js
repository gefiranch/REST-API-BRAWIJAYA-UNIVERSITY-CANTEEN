const { Router } = require("express");
const {
  listUserComments,
  listCanteenComments,
  addCommentCanteen,
  removeCommentCanteen,
} = require("../controllers/comment.controller");
const authMiddleware = require("../middlewares/auth");

const router = Router();

router.get("/user", authMiddleware, listUserComments);
router.get("/canteen/:id", authMiddleware, listCanteenComments);
router.post("/", authMiddleware, addCommentCanteen);
router.delete("/:id", authMiddleware, removeCommentCanteen);

module.exports = router;
