const { Router } = require("express");
const usersRoutes = require("./users.routes");
const canteensRoutes = require("./canteens.routes");
const favoritesRoutes = require("./favorites.routes");
const commentsRoutes = require("./comments.routes");

const router = Router();

router.use("/users", usersRoutes);
router.use("/canteens", canteensRoutes);
router.use("/favorites", favoritesRoutes);
router.use("/comments", commentsRoutes);

module.exports = router;
