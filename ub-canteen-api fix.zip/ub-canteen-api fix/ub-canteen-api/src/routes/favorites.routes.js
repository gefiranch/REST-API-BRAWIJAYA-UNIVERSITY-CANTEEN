const { Router } = require("express");
const {
  listFavorites,
  addFavoriteCanteen,
  removeFavoriteCanteen,
} = require("../controllers/favorite.controller");
const authMiddleware = require("../middlewares/auth");

const router = Router();

router.get("/", authMiddleware, listFavorites);
router.post("/", authMiddleware, addFavoriteCanteen);
router.delete("/:id", authMiddleware, removeFavoriteCanteen);

module.exports = router;
