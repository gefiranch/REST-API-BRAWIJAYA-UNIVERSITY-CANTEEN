const { Router } = require("express");
const {
  listCanteens,
  getCanteenDetail,
} = require("../controllers/canteen.controller");
const authMiddleware = require("../middlewares/auth");

const router = Router();

router.get("/", authMiddleware, listCanteens);
router.get("/:id", authMiddleware, getCanteenDetail);

module.exports = router;
