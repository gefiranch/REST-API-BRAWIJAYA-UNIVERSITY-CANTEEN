const {
  getCommentsByUserId,
  getCommentsByCanteenId,
  addComment,
  removeComment,
} = require("../services/comment.service");

const listUserComments = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const comments = await getCommentsByUserId(userId);
    return res.status(200).json(comments);
  } catch (err) {
    next(err);
  }
};

const listCanteenComments = async (req, res, next) => {
  try {
    const canteenId = req.params.id;
    if (!canteenId) {
      const err = new Error("Canteen ID is required");
      err.status = 400;
      throw err;
    }

    const comments = await getCommentsByCanteenId(canteenId);
    return res.status(200).json(comments);
  } catch (err) {
    next(err);
  }
};

const addCommentCanteen = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { canteenId, comment } = req.body;

    if (!canteenId || !comment) {
      const err = new Error("Canteen ID and comment are required");
      err.status = 400;
      throw err;
    }

    await addComment(userId, canteenId, comment);
    return res.status(201).json({ message: "Comment added successfully" });
  } catch (err) {
    next(err);
  }
};

const removeCommentCanteen = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const commentId = req.params.id;

    if (!commentId) {
      const err = new Error("Comment ID is required");
      err.status = 400;
      throw err;
    }

    await removeComment(commentId, userId);
    return res.status(200).json({ message: "Comment removed successfully" });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  listUserComments,
  listCanteenComments,
  addCommentCanteen,
  removeCommentCanteen,
};
