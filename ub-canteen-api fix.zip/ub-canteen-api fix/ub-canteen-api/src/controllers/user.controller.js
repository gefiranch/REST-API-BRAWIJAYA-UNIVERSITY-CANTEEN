const { register, login } = require("../services/user.service");

const registerUser = async (req, res) => {
  try {
    const { email, name, password } = req.body;

    if (!email || !name || !password) {
      const err = new Error("All fields are required");
      err.status = 400;
      throw err;
    }

    const result = await register(email, name, password);
    return res.status(201).json({ message: result.message });
  } catch (err) {
    next(err);
  }
};

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      const err = new Error("Email and password are required");
      err.status = 400;
      throw err;
    }

    const result = await login(email, password);
    return res.status(200).json({
      message: "Login successful",
      token: result.token,
      user: result.user,
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { registerUser, loginUser };
