const {
  getAllCanteens,
  getCanteenById,
} = require("../services/canteen.service");

const listCanteens = async (req, res, next) => {
  try {
    const canteens = await getAllCanteens();
    return res.status(200).json(canteens);
  } catch (err) {
    next(err);
  }
};

const getCanteenDetail = async (req, res, next) => {
  try {
    const canteen = await getCanteenById(req.params.id);
    return res.status(200).json(canteen);
  } catch (err) {
    next(err);
  }
};

module.exports = { listCanteens, getCanteenDetail };
