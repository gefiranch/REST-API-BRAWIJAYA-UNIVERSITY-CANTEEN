const {
  getFavoritesByUserId,
  addFavorite,
  removeFavorite,
} = require("../services/favorite.service");

const listFavorites = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const favorites = await getFavoritesByUserId(userId);
    return res.status(200).json(favorites);
  } catch (err) {
    next(err);
  }
};

const addFavoriteCanteen = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { canteenId } = req.body;

    if (!canteenId) {
      const err = new Error("Canteen ID is required");
      err.status = 400;
      throw err;
    }

    await addFavorite(userId, canteenId);
    return res.status(201).json({ message: "Canteen added to favorites" });
  } catch (err) {
    next(err);
  }
};

const removeFavoriteCanteen = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const canteenId = req.params.id;

    if (!canteenId) {
      const err = new Error("Canteen ID is required");
      err.status = 400;
      throw err;
    }

    await removeFavorite(userId, canteenId);
    return res.status(200).json({ message: "Canteen removed from favorites" });
  } catch (err) {
    next(err);
  }
};

module.exports = { listFavorites, addFavoriteCanteen, removeFavoriteCanteen };
